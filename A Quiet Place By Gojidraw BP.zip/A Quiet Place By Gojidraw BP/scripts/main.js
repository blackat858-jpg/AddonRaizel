import {
    Player,
    world,
    system
} from "@minecraft/server";

world.afterEvents.itemUse.subscribe((data) => {

 const player = data.source;
 const item = data.itemStack;
 const itemCD = item.getComponent("minecraft:cooldown");
 const cooldown = itemCD?.getCooldownTicksRemaining(player);

 if (cooldown >= 0.1) {
    return;
}

 switch (item.typeId) {
 case 
 'gojidraw:hearing_aid':
    player.runCommand(            "event entity @e[family=gojidraw_death_angel,r=10] goji:trigger");
    player.runCommand(            "playsound mob.death_angel.hearing_aid @a [r=20]");
    itemCD.startCooldown(player);
      break;
      
    }
});